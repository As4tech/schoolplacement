<div class="pull-right">
            copywrite @2023 <a href="">Admissions</a>
          </div>
          <div class="clearfix"></div>