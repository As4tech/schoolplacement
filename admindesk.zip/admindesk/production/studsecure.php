<?php 
SESSION_START();
if($_SESSION['stdname']='@!987$&[]2@A')
{header("location:/placement/oneschool/studlogin.php");
}
?>
