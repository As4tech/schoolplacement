<footer>
 <div class="pull-right">
          copywrite@2023 <a href="">admissions</a>
        </div>
        <div class="clearfix"></div>
</footer>